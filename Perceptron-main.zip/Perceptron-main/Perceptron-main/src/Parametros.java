public class Parametros {
    //Parametros Globales
    public static double Alpha;
    public static double[] entradas;
    public static double Sdeseada;


    //Neurona N01
    public static double S11;
    public static double[] AWN01;
    public static double delta01;
    public static double[] WN01;
    public static double V11;
    //Neurona N02
    public static double S12;
    public static double[] AWN02;
    public static double delta02;
    public static double[] WN02;
    public static double V12;
    //Neurona N11
    public static double Sobtenida;
    public static double[] AWN11;
    public static double[] WN11;
    public static double deltaSalida;

    public static void inicializarParametros() {

        Alpha = 0.403214001562446;
        entradas = new double[]{1, 0.970676779514179, 0.342439293861389};
        Sdeseada = 0.749880970455706;

        WN01 = new double[]{-0.650949932169169, -1.00542204687372, -2.64463176485151};
        WN02 = new double[]{-1.16517974296585, -1.91337396623567, -1.2914905953221};
        WN11 = new double[]{-1.87310829060152, 2.56109725916758, -1.51961972238496};

    }


}
