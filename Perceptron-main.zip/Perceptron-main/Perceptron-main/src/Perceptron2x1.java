public class Perceptron2x1 {

    private Parametros parametros;
    private Neurona n01;
    private Neurona n02;
    private Neurona n11;


    public Perceptron2x1(Parametros parametros, Neurona neurona1, Neurona neurona2, Neurona neurona3) {

        this.n01 = neurona1;
        this.n02 = neurona2;
        this.n11 = neurona3;
        n01.setEntradas(parametros.entradas);
        n02.setEntradas(parametros.entradas);
        n01.setPesos(parametros.WN01);
        n02.setPesos(parametros.WN02);
        n11.setPesos(parametros.WN11);

    }

    public void ciclo() {
        propagacion();
        retroPropagacion();
    }

    public void propagacion() {
        calcularSalidas();
    }

    public void calcularSalidas() {
        parametros.S11 = n01.calcularSalida();
        parametros.S12 = n02.calcularSalida();
        n11.setEntradas(new double[]{parametros.entradas[0], parametros.S11, parametros.S12});
        parametros.Sobtenida = n11.calcularSalida();
    }

    public void retroPropagacion() {
        calcularDeltaSalida();
        calcularDeltasOculta();
        calcularPesos();
        actualizarPesos();

    }

    private void calcularPesos() {
        double[] pesos1 = new double[3];
        double[] pesos2 = new double[3];


        for (int i = 0; i < pesos1.length; i++) {
            pesos1[i] = parametros.Alpha * parametros.entradas[i] * parametros.delta01;
            pesos2[i] = parametros.Alpha * parametros.entradas[i] * parametros.delta02;
        }


        double[] pesos3 = {
                parametros.entradas[0] * parametros.Alpha * parametros.deltaSalida,
                parametros.Alpha * parametros.deltaSalida * parametros.S11,
                parametros.Alpha * parametros.deltaSalida * parametros.S12};
        parametros.AWN01 = pesos1;
        parametros.AWN02 = pesos2;
        parametros.AWN11 = pesos3;
    }

    private void actualizarPesos() {

        for (int i = 0; i < 3; i++) {
            parametros.WN01[i] += parametros.AWN01[i];
            parametros.WN02[i] += parametros.AWN02[i];
            parametros.WN11[i] += parametros.AWN11[i];
        }

    }

    private void calcularDeltasOculta() {
        calcularV();
        parametros.delta01 = parametros.V11 * parametros.S11 * (1 - parametros.S11);
        parametros.delta02 = parametros.V12 * parametros.S12 * (1 - parametros.S12);

    }

    public void calcularV() { //calcula la V de las neuronas ocultas

        parametros.V11 = parametros.deltaSalida * parametros.WN11[1];

        parametros.V12 = parametros.deltaSalida * parametros.WN11[2];

    }


    public void calcularDeltaSalida() {
        parametros.deltaSalida = (parametros.Sdeseada - parametros.Sobtenida) * parametros.Sobtenida * (1 - parametros.Sobtenida);

    }


    public void actualizarNeuronas() {
        n01.setPesos(parametros.WN01);
        n02.setPesos(parametros.WN02);
        n11.setPesos(parametros.WN11);

    }


}
