public class Neurona {
    private double[] pesos;
    private double[] entradas;

    private double salida;

    public Neurona() {

    }

    public void setEntradas(double[] parametroEntradas){
        entradas = parametroEntradas;
    }

    public void setPesos(double[] parametroPesos) {
        pesos = parametroPesos;
    }

    public double calcularSalida() {
        double resultado = 0;

        for (int i = 0; i < entradas.length; i++){
            resultado += pesos[i] * entradas[i];
        }

        resultado = 1/(1+Math.exp(-resultado));
        salida = resultado;
        return resultado;
    }

    public double getSalida(){
        return salida;
    }

    public void setEntradas(double[] parametroEntradas){
        entradas = parametroEntradas;
    }

    public void setPesos(double[] parametroPesos) {
        pesos = parametroPesos;
    }

}
