public class MainPage {


    public static void main(String[] args) {
        Parametros parametros = new Parametros();
        parametros.inicializarParametros();
        Neurona neurona1 = new Neurona();
        Neurona neurona2 = new Neurona();
        Neurona neurona3 = new Neurona();
        Perceptron2x1 perceptron2x1 = new Perceptron2x1(parametros, neurona1, neurona2, neurona3);
        perceptron2x1.ciclo();



    }

}
