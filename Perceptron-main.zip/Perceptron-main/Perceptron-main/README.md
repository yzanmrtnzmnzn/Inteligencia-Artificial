# Perceptron
perceptron multicapa
perceptron multipollas deberian llamarle joder que complicado
